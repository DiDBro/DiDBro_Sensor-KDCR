function [M,C,N] = MCN(xi,calMp,lM,beta,mg,theta,dtheta)
    %% 
    % We calculate $e^{\hat{\xi}\theta}$ for each joint.
    gg = zeros(4,4,3);
    gg(1:4,1:4,1) = gtwist_num(xi(:,1),theta(1));
    gg(1:4,1:4,2) = gtwist_num(xi(:,2),theta(2));
    gg(1:4,1:4,3) = gtwist_num(xi(:,3),theta(3));
    %%  
    % Calculation of all possible $A_{lj}$ and all possible $A_{lj}\xi_j$,
    % using eq. (4.27) p. 176.
    % (Use indices as on p. 177 and not as in eq. (4.27).  "ll" is row
    %   index and "jj" is column index.)
    Alj = zeros(6,6,3,3);
    Al  = zeros(6,3,3);
    for jj = 1:3
        for ll = jj:3
            ggjl = eye(4);
            for kk = jj+1:ll
                ggjl = ggjl*gg(:,:,kk);
            end
            Alj(1:6,1:6,ll,jj) = adjmginv(ggjl);
        end
    end
    
    for jj = 1:3
        for ll = 1:3
            Al(1:6,ll,jj)  = Alj(1:6,1:6,ll,jj)*xi(:,jj);
        end
    end
    %% 
    % Calculation of $M(\theta)$ without utilizing the fact that it is
    %    symmetric.
    M = zeros(3);
    for ii = 1:3
        for jj = 1:3
            for ll = lM(ii,jj):3
                M(ii,jj) = M(ii,jj) + ...
                    Al(1:6,ll,ii)'*calMp(1:6,1:6,ll)*Al(1:6,ll,jj);
            end
        end
    end
    %% 
    % Calculation of
    % 
    % $$\frac{\partial M_{ij}}{\partial \theta_k}$$
    Ck  = zeros(3,3,3);
    for kk = 1:3
        Ckk = zeros(3,3);
        for ii = 1:3
            for jj = 1:3
                for ll = lM(ii,jj):3
                    dumii = Alkliejk_nca(Alj,Al,xi,ll,kk,ii);
                    dumjj = Alkliejk_nca(Alj,Al,xi,ll,kk,jj);
                    
                    Ckk(ii,jj) = Ckk(ii,jj) + ...
                    dumii'*calMp(1:6,1:6,ll)*Al(1:6,ll,jj) + ...
                    Al(1:6,ll,ii)'*calMp(1:6,1:6,ll)*dumjj;
                end
            end
        end
        Ck(1:3,1:3,kk) = Ckk;
    end
    %% 
    % Calculation of $C(\theta,\dot{\theta})$
    C = zeros(3,3);
    for ii = 1:3
        for jj = 1:3
            dum = 0;
            for kk = 1:3
                dum = dum + ( Ck(ii,jj,kk) + Ck(ii,kk,jj) - ...
                      Ck(kk,jj,ii) )*dtheta(kk);
            end
            C(ii,jj) = dum/2;
        end
    end
    %%
    % Caculation of $N(\theta,\dot{\theta})$
    N    = zeros(3,1);
    ct2  = cos(theta(2));
    N(1,1) = beta(1)*dtheta(1);
    N(2,1) = beta(2)*dtheta(2) - mg(2)*ct2/6 - mg(3)*ct2*19/30;
    N(3,1) = beta(3)*dtheta(3);

end
